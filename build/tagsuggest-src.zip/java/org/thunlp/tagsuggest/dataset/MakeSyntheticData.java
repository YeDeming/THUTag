package org.thunlp.tagsuggest.dataset;

import org.thunlp.tool.GenericTool;

/**
 * Make synthetic data, with words and tags.
 * @author sixiance
 *
 */
public class MakeSyntheticData implements GenericTool {

  @Override
  public void run(String[] args) throws Exception {

  }

}
