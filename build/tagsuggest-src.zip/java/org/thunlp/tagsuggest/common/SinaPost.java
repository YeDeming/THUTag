/**
 * Created：May 22, 2013 10:03:41 PM  
 * Project：cxx  
 * @author cxx
 * @since JDK 1.6.0_13  
 * filename：SinaPost.java  
 * description：  
 */
package org.thunlp.tagsuggest.common;

public class SinaPost extends Post {
	private String description = "";

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
